
const searchForm = document.getElementById('searchForm');
const searchInput = document.getElementById('searchInput');
const products = document.querySelectorAll('.products');

searchForm.addEventListener('submit', (e) => {
    e.preventDefault();
    const query = searchInput.value.toLowerCase();

    products.forEach(product => {
        const name = product.dataset.name.toLowerCase();

        if (name.includes(query)) {
            product.style.display = 'inline-block';
        } else {
            product.style.display = 'none';
        }
    });
});



const orderButtons = document.querySelectorAll('.order-btn');
const modal = document.getElementById('loginModal');
const closeButtons = document.querySelectorAll('.close');

orderButtons.forEach(btn => {
    btn.addEventListener('click', (e) => {
        e.preventDefault();
        modal.style.display = 'block';
    });
});


closeButtons.forEach(button => {
    button.addEventListener('click', () => {
        modal.style.display = 'none';
    });
});


window.addEventListener('click', (e) => {
    if (e.target === modal) {
        modal.style.display = 'none';
    }
});



document.addEventListener("DOMContentLoaded", () => {
    const buttons = document.querySelectorAll(".add-to-cart-btn");

    buttons.forEach(btn => {
        btn.addEventListener("click", () => {
            const product = btn.closest(".products");
            const name = product.dataset.name;
            const price = parseFloat(product.dataset.price);

            let cart = JSON.parse(localStorage.getItem("cart")) || [];
            cart.push({ name, price });
            localStorage.setItem("cart", JSON.stringify(cart));

            alert(`${name} added to cart!`);
        });
    });
});

orderButtons.forEach(btn => {
    btn.addEventListener('click', (e) => {
        e.preventDefault();

        
        const loggedIn = localStorage.getItem("loggedIn");

        if (!loggedIn) {
            modal.style.display = "block"; 
            return;
        }

        
        alert("You can now place your order!");
    });
});

