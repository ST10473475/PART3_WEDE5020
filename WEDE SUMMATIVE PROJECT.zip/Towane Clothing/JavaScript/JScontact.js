document.addEventListener("DOMContentLoaded", () => {
    const contactForm = document.querySelector(".form");

    if(contactForm){
        contactForm.addEventListener("submit", (e) =>{
            e.preventDefault();

            const name = document.getElementById("name").value.trim();
            const  email = document.getElementById("email").value.trim();
            const message = document.getElementById("message").value.trim();

            if(name === "" || email === "" || message ===""){
                alert("Please fill in all fields");
                return;
            }

            const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if(!emailPattern.test(email)){
                alert("Please enter a valid email address.");
                return;
            }

            alert("Thank you! Your message has been sent successfully. ");
            contactForm.reset();

        });
    }
});