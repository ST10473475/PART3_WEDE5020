document.addEventListener("DOMContentLoaded", () => {
    const newsForm= document.querySelector("#newsForm");

    if(newsForm){
        newsForm.addEventListener("submit", (e) =>{
            e.preventDefault();

            const  email = document.getElementById("newsletter").value.trim();

            const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if(!emailPattern.test(email)){
                alert("Please enter a valid email address.");
                return;
            }

            alert(`Thank you for subscribing with ${email}`);
            newsForm.reset();

        });
    }
});