document.addEventListener("DOMContentLoaded", () => {
    let cart = JSON.parse(localStorage.getItem("cart")) || [];

    const cartItems = document.getElementById("cartItems");
    const cartTotal = document.getElementById("cartTotal");
    const checkoutBtn = document.getElementById("checkoutBtn");
    const modal = document.getElementById("loginModal");
    const addButtons = document.querySelectorAll(".add-to-cart-btn");

    function updateCart() {
        cartItems.innerHTML = "";
        let total = 0;

        cart.forEach((item, index) => {
            total += item.price;

            const li = document.createElement("li");
            li.innerHTML = `${item.name} - R${item.price.toFixed(2)}
                <button onclick="removeItem(${index})">Remove</button>`;
            cartItems.appendChild(li);
        });

        cartTotal.textContent = total.toFixed(2);
    }

    window.removeItem = function(index) {
        cart.splice(index, 1);
        localStorage.setItem("cart", JSON.stringify(cart));
        updateCart();
    };

    updateCart();

    // Add to cart buttons
    addButtons.forEach(btn => {
        btn.addEventListener("click", () => {
            const loggedIn = localStorage.getItem("loggedIn");
            if (!loggedIn) {
                modal.style.display = "block";
                return;
            }

            const product = btn.closest(".products");
            const name = product.dataset.name;
            const price = parseFloat(product.dataset.price.replace(/[^0-9.]/g, ""));

            cart.push({ name, price });
            localStorage.setItem("cart", JSON.stringify(cart));
            updateCart();
            alert(`${name} added to cart!`);
        });
    });

    // Checkout button
    checkoutBtn.addEventListener("click", () => {
        const loggedIn = localStorage.getItem("loggedIn");

        if (!loggedIn) {
            modal.style.display = "block";
            return;
        }

        if (cart.length === 0) {
            alert("Your cart is empty!");
            return;
        }

        const total = cart.reduce((sum, item) => sum + item.price, 0).toFixed(2);
        alert(`Thank you for your order! Total: R${total}`);

        // Clear cart
        cart = [];
        localStorage.setItem("cart", JSON.stringify(cart));
        updateCart();
    });
});
