document.addEventListener("DOMContentLoaded", () => {
    const signupForm= document.querySelector("#signupForm");

    if(signupForm){
        signupForm.addEventListener("submit", (e) =>{
            e.preventDefault();

            const  name = document.getElementById("name").value.trim();
            const email = document.getElementById("email").value.trim();
             const  password = document.getElementById("password").value.trim();
            const confirmPassword = document.getElementById("confirmPassword").value.trim();


            if(name === "" || email === "" || password === "" || confirmPassword === ""){
                alert("Please fill in all fields");
                return;
            }

            const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if(!emailPattern.test(email)){
                alert("Please enter a valid email address.");
                return;
            }

            if(password !== confirmPassword){
                alert("Passwords do not match");
                return;
            }

            alert("SignUp Successful. ");
            signupForm.reset();

        });
    }
});