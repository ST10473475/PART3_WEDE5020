document.addEventListener("DOMContentLoaded", () => {
    const signinForm= document.querySelector("#signinForm");

    if(signinForm){
        signinForm.addEventListener("submit", (e) =>{
            e.preventDefault();

            const  email = document.getElementById("email").value.trim();
            const password = document.getElementById("password").value.trim();

            if(email === "" || password === ""){
                alert("Please fill in all fields");
                return;
            }

            const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if(!emailPattern.test(email)){
                alert("Please enter a valid email address.");
                return;
            }

            alert("SignIn Successful. ");
            signinForm.reset();

        });
    }
});